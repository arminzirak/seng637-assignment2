package org.jfree.data;

/**
 * @author_MingruiYu
 *
 */
import static org.junit.Assert.*;

import java.security.InvalidParameterException;

import org.jfree.data.Range;
import org.junit.*;
import static org.mockito.Mockito.*;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import com.sun.tools.javac.util.List;

import org.junit.rules.ExpectedException;

public class DataUtilitiesTest {
	private KeyedValues mockKeyedValues;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

//@Before
//public void setUp() throws Exception { 
//	exampleRange = new DataUtilities();
//}

	@Rule
	public MockitoRule mockitoRule = MockitoJUnit.rule();

	@Before
	public void setUp() throws Exception {

	}

	@Test
	public void createNumberArray2D() {

		double[][] table = new double[3][];
		table[0] = new double[] { 1.0, 2.0, 3.0, 4.0 };
		table[1] = new double[] { 1.0, 2.0, 3.0, 4.0 };
		table[2] = new double[] { 1.0, 2.0, 3.0, 4.0 };
		Number[][] n = DataUtilities.createNumberArray2D(table);
		assertEquals(3, n.length);
		assertEquals(4, n[0].length);
	}

	@Test
	public void createNumberArray() {

		double[] table = new double[] { 1.0, 2.0, 3.0, 4.0 };
		Number[] n = DataUtilities.createNumberArray(table);
		assertEquals(4, n.length);
	}

	@Test
	public void testcalculateColumnTotal() {
		Values2D mockValues2D = mock(Values2D.class);
		Assert.assertTrue(mockValues2D instanceof Values2D);
		when(mockValues2D.getRowCount()).thenReturn(3);
		when(mockValues2D.getColumnCount()).thenReturn(3);
		when(mockValues2D.getValue(0, 0)).thenReturn(1);
		when(mockValues2D.getValue(0, 1)).thenReturn(2);
		when(mockValues2D.getValue(0, 2)).thenReturn(3);
		when(mockValues2D.getValue(1, 0)).thenReturn(1);
		when(mockValues2D.getValue(1, 1)).thenReturn(2);
		when(mockValues2D.getValue(1, 2)).thenReturn(3);
		when(mockValues2D.getValue(2, 0)).thenReturn(1);
		when(mockValues2D.getValue(2, 1)).thenReturn(2);
		when(mockValues2D.getValue(2, 2)).thenReturn(3);

		assertEquals(3, DataUtilities.calculateColumnTotal(mockValues2D, 0), 0.001);
		assertEquals(6, DataUtilities.calculateColumnTotal(mockValues2D, 1), 0.001);
		assertEquals(9, DataUtilities.calculateColumnTotal(mockValues2D, 2), 0.001);
		assertEquals(0, DataUtilities.calculateColumnTotal(mockValues2D, 3), 0.001);

	}

	@Test
	public void testcalculateRowTotal() {
		Values2D mockValues2D = mock(Values2D.class);
		Assert.assertTrue(mockValues2D instanceof Values2D);
		when(mockValues2D.getRowCount()).thenReturn(3);
		when(mockValues2D.getColumnCount()).thenReturn(3);
		when(mockValues2D.getValue(0, 0)).thenReturn(1);
		when(mockValues2D.getValue(0, 1)).thenReturn(2);
		when(mockValues2D.getValue(0, 2)).thenReturn(3);
		when(mockValues2D.getValue(1, 0)).thenReturn(1);
		when(mockValues2D.getValue(1, 1)).thenReturn(2);
		when(mockValues2D.getValue(1, 2)).thenReturn(3);
		when(mockValues2D.getValue(2, 0)).thenReturn(1);
		when(mockValues2D.getValue(2, 1)).thenReturn(2);
		when(mockValues2D.getValue(2, 2)).thenReturn(3);

		assertEquals(6, DataUtilities.calculateRowTotal(mockValues2D, 0), 0.001);
		assertEquals(6, DataUtilities.calculateRowTotal(mockValues2D, 1), 0.001);
		assertEquals(6, DataUtilities.calculateRowTotal(mockValues2D, 2), 0.001);
		assertEquals(0, DataUtilities.calculateRowTotal(mockValues2D, 3), 0.001);
	}

	@Test(expected = NullPointerException.class)
	public void NULLdata() {
		try {
			DataUtilities.calculateRowTotal(null, 2);
			fail();
		} catch (NullPointerException e) {
		}
		try {
			DataUtilities.calculateColumnTotal(null, 2);
			fail();
		} catch (NullPointerException e) {
		}
		try {
			DataUtilities.createNumberArray(null);
			fail();
		} catch (IllegalArgumentException e) {
		}
		try {
			DataUtilities.createNumberArray2D(null);
			fail();
		} catch (IllegalArgumentException e) {
		}
		try {
			DataUtilities.getCumulativePercentages(null);
		} catch (InvalidParameterException ex) {
			throw ex;
		} catch (Exception ex) {
		}

	}

	@Test

	public void testgetCumulativePercentages() {
		KeyedValues mockKeyedValues = mock(KeyedValues.class);
		Assert.assertTrue(mockKeyedValues instanceof KeyedValues);
		when(mockKeyedValues.getItemCount()).thenReturn(4);

		when(mockKeyedValues.getKey(0)).thenReturn(0);
		when(mockKeyedValues.getKey(1)).thenReturn(1);
		when(mockKeyedValues.getKey(2)).thenReturn(2);
		when(mockKeyedValues.getKey(3)).thenReturn(3);

		when(mockKeyedValues.getValue(0)).thenReturn(1.0);
		when(mockKeyedValues.getValue(1)).thenReturn(5.0);
		when(mockKeyedValues.getValue(2)).thenReturn(10.0);
		when(mockKeyedValues.getValue(3)).thenReturn(15.0);

		KeyedValues result = DataUtilities.getCumulativePercentages(mockKeyedValues);

		assertEquals(1.0 / 31.0, result.getValue(0));
		assertEquals(6.0 / 31.0, result.getValue(1));
		assertEquals(16.0 / 31.0, result.getValue(2));
		assertEquals(31.0 / 31.0, result.getValue(3));
	}

}
